# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 14:00:21 2025

@author: ed
"""

import matplotlib.pyplot as plt

from nhf_spec import nhf_spec

file = "spec_test.nhf"

afm = nhf_spec(file)

# list segment names
print(afm.seg_names)

# list channel names
print(afm.chan_names)

# how many force curves in dataset?
print(r"Number: %i" % afm.param["number"])

# get deflection (in volts) and Z-position data for 10th retract curve
num = 9  # python indexes at 0 so 10 -> 9
d = afm.data(segment="Retract", channel="Deflection", N=num)
z = afm.data(segment="Retract", channel="Position Z", N=num)

# convert deflection to force
f = d * afm.param.probe_k * afm.param.probe_sens

# plot 10th force curve
plt.plot(z, f)
