Installation
------------

	python setup.py install

Requirements
------------

	Python 3
	numpy
	itertools

Optional Requirement
------------

	Pandas
	
Example
------------

	example/sample_script.py
	

	