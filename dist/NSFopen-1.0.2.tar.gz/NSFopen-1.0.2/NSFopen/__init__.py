# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 12:43:59 2019

@author: Edward
"""


from . NSFopen import read
